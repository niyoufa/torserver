# @Time    : 2018/3/12 10:54
# @Author  : Niyoufa

VERSION = (2, 0, 0, 'beta', 0)

__version__ = VERSION
