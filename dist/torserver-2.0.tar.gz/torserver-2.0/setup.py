# @Time    : 2018/3/27 15:49
# @Author  : Niyoufa
from setuptools import find_packages, setup
import pdb
pdb.set_trace()

setup(
    name='torserver',
    version='2.0',
    author="niyoufa",
    author_email="niyoufa@aegis-data.cn",
    packages=find_packages(),
    url="http://www.niyoufa.com",
    description="A web application framework base on tornado and other async libraries."
)